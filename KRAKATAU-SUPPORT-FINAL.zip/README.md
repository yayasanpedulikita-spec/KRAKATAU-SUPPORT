# KRAKATAU-SUPPORT — FINAL

## Upload ke GitHub Pages
1. Ekstrak ZIP.
2. Upload **seluruh isi folder** ke repository GitHub Pages.
3. Pastikan `index.html` berada di root repository (bukan di dalam folder lain).
4. Pastikan folder `assets/` ikut ter-upload dan berisi `qris.jpeg`.

## File
- `index.html` — halaman final
- `style.css` — tampilan responsive
- `script.js` — alur donasi + event tracking placeholder
- `assets/qris.jpeg` — QRIS asli dari paket yang diberikan

## Foto
Foto kampanye menggunakan URL langsung Wikimedia Commons yang sudah diketahui valid. Foto utama 5 September 2026 berasal dari dokumentasi Pemprov Lampung dan tercatat sebagai public domain di Wikimedia Commons. Foto 2022 adalah karya Evanradit12 dengan lisensi CC BY-SA 4.0.

Jika ingin **100% tanpa ketergantungan eksternal untuk foto**, upload file foto asli ke folder `assets/` dan ganti URL background di `style.css` menjadi nama file lokal. QRIS sudah lokal.

## Tracking
Script sudah menyediakan event:
- `LandingPageView`
- `DonateInitiated`
- `DonateAmountSelected`
- `QRISViewed`
- `DonationCompleted`

Meta Pixel tetap memerlukan Pixel ID dan pemasangan base code milik akun iklan kamu. Jangan memasukkan Pixel ID yang tidak kamu miliki.
